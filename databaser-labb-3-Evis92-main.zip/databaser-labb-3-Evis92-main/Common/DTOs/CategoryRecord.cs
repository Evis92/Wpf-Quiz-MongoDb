﻿namespace Common.DTOs;

public record CategoryRecord(string Id, string CategoryName);